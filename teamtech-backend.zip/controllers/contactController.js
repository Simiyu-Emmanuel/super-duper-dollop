const Contact = require('../models/Contact');

exports.handleContact = async (req, res) => {
  try {
    const contact = new Contact(req.body);
    await contact.save();
    res.status(200).json({ message: 'Message received' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to send message' });
  }
};
