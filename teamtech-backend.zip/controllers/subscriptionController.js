const Subscription = require('../models/Subscription');

exports.subscribe = async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email required' });

    const existing = await Subscription.findOne({ email });
    if (existing) return res.status(400).json({ error: 'Already subscribed' });

    const newSub = new Subscription({ email });
    await newSub.save();

    res.status(200).json({ message: 'Subscribed successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to subscribe' });
  }
};
